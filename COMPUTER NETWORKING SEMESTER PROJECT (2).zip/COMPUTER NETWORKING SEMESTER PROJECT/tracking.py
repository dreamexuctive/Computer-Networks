import pyshark
import geoip2.database
from collections import defaultdict


pcap_file = 'pca.png'  
geoip_db_path = 'GeoLite2-City.mmdb'  


reader = geoip2.database.Reader(geoip_db_path)


geoip_results = defaultdict(int)

cap = pyshark.FileCapture(pcap_file, display_filter='ip')

print("[*] Processing packets...")

for packet in cap:
    try:
        ip = packet.ip.dst
        response = reader.city(ip)
        city = response.city.name or "Unknown City"
        country = response.country.name or "Unknown Country"
        location = f"{city}, {country}"
        geoip_results[location] += 1
    except Exception:
        continue

cap.close()
reader.close()


print("\n[+] GeoIP Locations:")
for location, count in geoip_results.items():
    print(f"{location}: {count} packet(s)")
